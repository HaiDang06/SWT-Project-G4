package fu.swt301.sms.dao;

import fu.swt301.sms.entity.Role;
import fu.swt301.sms.entity.Staff;
import fu.swt301.sms.utils.DBUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StaffDAOTest {

    @Mock private Connection mockConnection;
    @Mock private PreparedStatement mockPreparedStatement;
    @Mock private ResultSet mockResultSet;

    // Đối tượng dùng để giả lập các method static của DBUtils
    private MockedStatic<DBUtils> mockedDBUtils;
    
    private StaffDAO staffDAO;

    @BeforeEach
    void setUp() throws SQLException, ClassNotFoundException {
        staffDAO = new StaffDAO();
        
        // Mở giả lập static cho DBUtils
        mockedDBUtils = mockStatic(DBUtils.class);
        
        // Khi DAO gọi DBUtils.getConnection(), trả về connection giả lập của chúng ta
        mockedDBUtils.when(DBUtils::getConnection).thenReturn(mockConnection);
        
        // Khi connection tạo PreparedStatement, trả về statement giả lập
        // Dùng lenient() để tránh lỗi StrictStubbing nếu có method không dùng đến mock này
        lenient().when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
    }

    @AfterEach
    void tearDown() {
        // Rất quan trọng: Phải đóng mock static sau mỗi test case để không ảnh hưởng test khác
        mockedDBUtils.close();
    }

    // Hàm tiện ích: Giả lập dữ liệu trả về từ Database cho đối tượng Staff
    private void mockResultSetForStaff() throws SQLException {
        when(mockResultSet.getInt("StaffID")).thenReturn(1);
        when(mockResultSet.getString("FullName")).thenReturn("Nguyen Van A");
        when(mockResultSet.getBoolean("Gender")).thenReturn(true);
        when(mockResultSet.getString("PhoneNumber")).thenReturn("0987654321");
        when(mockResultSet.getString("Email")).thenReturn("admin@fpt.edu.vn");
        when(mockResultSet.getString("Password")).thenReturn("hashed_password");
        when(mockResultSet.getBoolean("IsActive")).thenReturn(true);
        when(mockResultSet.getDate("Dob")).thenReturn(java.sql.Date.valueOf(LocalDate.of(1990, 1, 1)));
        when(mockResultSet.getString("Department")).thenReturn("IT");
        when(mockResultSet.getString("Position")).thenReturn("Manager");
        when(mockResultSet.getDouble("Salary")).thenReturn(2000.0);
        when(mockResultSet.getDate("HireDate")).thenReturn(java.sql.Date.valueOf(LocalDate.of(2020, 5, 10)));
        when(mockResultSet.getInt("Role_ID")).thenReturn(1);
        when(mockResultSet.getString("Role_Name")).thenReturn("ADMIN");
    }

    // --- 1. Test isEmailExists ---
    @Test
    void testIsEmailExists_True() throws Exception {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(1); // COUNT(*) = 1

        boolean result = staffDAO.isEmailExists("admin@fpt.edu.vn", 2);

        assertTrue(result, "Phải trả về true nếu email đã tồn tại");
        verify(mockPreparedStatement).setString(1, "admin@fpt.edu.vn");
        verify(mockPreparedStatement).setInt(2, 2);
    }

    @Test
    void testIsEmailExists_False() throws Exception {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(0); // COUNT(*) = 0

        boolean result = staffDAO.isEmailExists("newuser@fpt.edu.vn", 0);

        assertFalse(result, "Phải trả về false nếu email chưa tồn tại");
    }

    // --- 2. Test checkLogin ---
    @Test
    void testCheckLogin_Success() throws Exception {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true); // Có tìm thấy dữ liệu
        mockResultSetForStaff();

        Staff result = staffDAO.checkLogin("admin@fpt.edu.vn", "password");

        assertNotNull(result);
        assertEquals("Nguyen Van A", result.getFullName());
        assertEquals("IT", result.getDepartment());
        assertEquals("ADMIN", result.getRole().getRoleName());
    }

    @Test
    void testCheckLogin_Failure() throws Exception {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false); // Không tìm thấy dữ liệu (Sai email hoặc pass)

        Staff result = staffDAO.checkLogin("wrong@gmail.com", "wrongpass");

        assertNull(result);
    }

    // --- 3. Test createStaff ---
    @Test
    void testCreateStaff_Success() throws Exception {
        // Chuẩn bị dữ liệu đầu vào
        Staff newStaff = new Staff();
        newStaff.setFullName("Le Van B");
        newStaff.setGender(false);
        newStaff.setPhoneNumber("0111222333");
        newStaff.setEmail("levanb@fpt.edu.vn");
        newStaff.setPassword("pass123");
        newStaff.setIsActive(true);
        newStaff.setDob(LocalDate.of(1995, 2, 2));
        newStaff.setDepartment("HR");
        newStaff.setPosition("Staff");
        newStaff.setSalary(1500.0);
        newStaff.setHireDate(LocalDate.now());
        
        Role role = new Role();
        role.setRoleID(2);
        newStaff.setRole(role);

        // Execute Update
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        staffDAO.createStaff(newStaff);

        // Verify các parameter đã được set đúng vào câu query chưa
        verify(mockPreparedStatement).setString(1, "Le Van B");
        verify(mockPreparedStatement).setBoolean(2, false);
        verify(mockPreparedStatement).setString(3, "0111222333");
        verify(mockPreparedStatement).setInt(6, 2); // Role ID
        verify(mockPreparedStatement, times(1)).executeUpdate();
    }

    // --- 4. Test getStaffByFilterPaging ---
    @Test
    void testGetStaffByFilterPaging() throws Exception {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        // Trả về true 1 lần (đại diện cho 1 record), lần 2 trả về false để kết thúc vòng lặp while
        when(mockResultSet.next()).thenReturn(true, false);
        mockResultSetForStaff();

        // Search: searchId="1", searchName="Nguyen", searchDept="IT", offset=0, limit=10
        List<Staff> resultList = staffDAO.getStaffByFilterPaging("1", "Nguyen", "IT", 0, 10);

        assertEquals(1, resultList.size());
        assertEquals(1, resultList.get(0).getStaffID());
        assertEquals("Nguyen Van A", resultList.get(0).getFullName());

        // Kiểm tra xem limit và offset đã được set cuối cùng trong câu PreparedStatement chưa
        // Vì có 3 tham số search đều pass IF, paramIndex cuối cùng sẽ là 4 (limit) và 5 (offset)
        verify(mockPreparedStatement).setInt(4, 10);
        verify(mockPreparedStatement).setInt(5, 0);
    }
    
    // --- 5. Test deleteStaff ---
    @Test
    void testDeleteStaff() throws Exception {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);
        
        staffDAO.deleteStaff(5); // Xoá nhân viên ID = 5
        
        verify(mockPreparedStatement).setInt(1, 5);
        verify(mockPreparedStatement, times(1)).executeUpdate();
    }
    // --- 6. Test updateAccountStatus ---
    @Test
    void testUpdateAccountStatus() throws Exception {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeUpdate()).thenReturn(1); // Giả lập update thành công 1 dòng

        boolean result = staffDAO.updateAccountStatus(1, false); // Khoá tài khoản ID = 1

        assertTrue(result, "Phải trả về true khi update thành công");
        verify(mockPreparedStatement).setBoolean(1, false);
        verify(mockPreparedStatement).setInt(2, 1);
        verify(mockPreparedStatement, times(1)).executeUpdate();
    }

    // --- 7. Test updatePassword ---
    @Test
    void testUpdatePassword() throws Exception {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean result = staffDAO.updatePassword(2, "new_hashed_password");

        assertTrue(result);
        verify(mockPreparedStatement).setString(1, "new_hashed_password");
        verify(mockPreparedStatement).setInt(2, 2);
        verify(mockPreparedStatement, times(1)).executeUpdate();
    }
}