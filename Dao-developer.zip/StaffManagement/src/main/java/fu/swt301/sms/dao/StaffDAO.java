package fu.swt301.sms.dao;

import fu.swt301.sms.entity.Role;
import fu.swt301.sms.entity.Staff;
import fu.swt301.sms.utils.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object (DAO) for the Staff entity.
 * Refactored for Unit Testing (H2 Database support) and Auth Security.
 */
public class StaffDAO {

    /**
     * MỞ CHỐT TESTABILITY: Hàm này giúp lấy Connection. 
     * Khi chạy thật, nó gọi DBUtils. Khi viết Unit Test, cậu có thể Override nó để trả về H2 Connection.
     */
    protected Connection getConnection() throws SQLException, ClassNotFoundException {
        return DBUtils.getConnection();
    }

    private Staff extractStaffFromResultSet(ResultSet rs) throws SQLException {
        Staff staff = new Staff();
        staff.setStaffID(rs.getInt("StaffID"));
        staff.setFullName(rs.getString("FullName"));
        staff.setGender(rs.getBoolean("Gender"));
        staff.setPhoneNumber(rs.getString("PhoneNumber"));
        staff.setEmail(rs.getString("Email"));
        staff.setPassword(rs.getString("Password")); 
        staff.setIsActive(rs.getBoolean("IsActive"));

        // Tối ưu hóa việc gọi rs.getDate() để tránh gọi 2 lần
        java.sql.Date dobDate = rs.getDate("Dob");
        if (dobDate != null) staff.setDob(dobDate.toLocalDate());
        
        staff.setDepartment(rs.getString("Department"));
        staff.setPosition(rs.getString("Position"));
        staff.setSalary(rs.getDouble("Salary"));
        
        java.sql.Date hireDate = rs.getDate("HireDate");
        if (hireDate != null) staff.setHireDate(hireDate.toLocalDate());

        Role role = new Role();
        role.setRoleID(rs.getInt("Role_ID"));
        role.setRoleName(rs.getString("Role_Name"));
        staff.setRole(role);

        return staff;
    }

    public boolean isEmailExists(String email, int currentStaffId) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM Staff WHERE Email = ? AND StaffID != ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setInt(2, currentStaffId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public boolean isFullNameExists(String fullName, int currentStaffId) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM Staff WHERE FullName = ? AND StaffID != ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, fullName);
            ps.setInt(2, currentStaffId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public boolean isPhoneNumberExists(String phoneNumber, int currentStaffId) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM Staff WHERE PhoneNumber = ? AND StaffID != ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, phoneNumber);
            ps.setInt(2, currentStaffId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public Staff checkLogin(String email, String password) {
        String sql = "SELECT s.*, r.Role_Name FROM Staff s JOIN Role r ON s.Role_ID = r.Role_ID WHERE s.Email = ? AND s.Password = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return extractStaffFromResultSet(rs);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Staff> getStaffByFilter(String name, String status) {
        List<Staff> staffList = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT s.*, r.Role_Name FROM Staff s JOIN Role r ON s.Role_ID = r.Role_ID WHERE 1=1");
        if (name != null && !name.isEmpty()) sql.append(" AND s.FullName LIKE ?");
        if (status != null && !status.isEmpty()) sql.append(" AND s.IsActive = ?");
        
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            if (name != null && !name.isEmpty()) ps.setString(paramIndex++, "%" + name + "%");
            if (status != null && !status.isEmpty()) ps.setBoolean(paramIndex, Boolean.parseBoolean(status));
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) staffList.add(extractStaffFromResultSet(rs));
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return staffList;
    }

    public void createStaff(Staff staff) {
        String sql = "INSERT INTO Staff (FullName, Gender, PhoneNumber, Email, Password, Role_ID, IsActive, Dob, Department, Position, Salary, HireDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, staff.getFullName());
            ps.setBoolean(2, staff.isGender());
            ps.setString(3, staff.getPhoneNumber());
            ps.setString(4, staff.getEmail());
            ps.setString(5, staff.getPassword());
            ps.setInt(6, staff.getRole().getRoleID());
            ps.setBoolean(7, staff.isIsActive());
            ps.setDate(8, staff.getDob() != null ? java.sql.Date.valueOf(staff.getDob()) : null);
            ps.setString(9, staff.getDepartment());
            ps.setString(10, staff.getPosition());
            ps.setDouble(11, staff.getSalary());
            ps.setDate(12, staff.getHireDate() != null ? java.sql.Date.valueOf(staff.getHireDate()) : null);
            ps.executeUpdate();
        } catch (Exception e) { 
            throw new RuntimeException("Lỗi khi thêm mới nhân viên: " + e.getMessage(), e);
        }
    }

    public void updateStaff(Staff staff) {
        String sql = "UPDATE Staff SET FullName = ?, Gender = ?, PhoneNumber = ?, Email = ?, Role_ID = ?, IsActive = ?, Dob = ?, Department = ?, Position = ?, Salary = ?, HireDate = ? WHERE StaffID = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, staff.getFullName());
            ps.setBoolean(2, staff.isGender());
            ps.setString(3, staff.getPhoneNumber());
            ps.setString(4, staff.getEmail());
            ps.setInt(5, staff.getRole().getRoleID());
            ps.setBoolean(6, staff.isIsActive());
            ps.setDate(7, staff.getDob() != null ? java.sql.Date.valueOf(staff.getDob()) : null);
            ps.setString(8, staff.getDepartment());
            ps.setString(9, staff.getPosition());
            ps.setDouble(10, staff.getSalary());
            ps.setDate(11, staff.getHireDate() != null ? java.sql.Date.valueOf(staff.getHireDate()) : null);
            ps.setInt(12, staff.getStaffID());
            ps.executeUpdate();
        } catch (Exception e) { 
            throw new RuntimeException("Lỗi khi cập nhật nhân viên: " + e.getMessage(), e); 
        }
    }

    public void deleteStaff(int staffId) {
        String sql = "DELETE FROM Staff WHERE StaffID = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException("Lỗi khi xoá nhân viên: " + e.getMessage(), e);
        }
    }

    public Staff getStaffById(int staffId) {
        String sql = "SELECT s.*, r.Role_Name FROM Staff s JOIN Role r ON s.Role_ID = r.Role_ID WHERE s.StaffID = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return extractStaffFromResultSet(rs);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Staff getStaffByEmail(String email) {
        String sql = "SELECT s.*, r.Role_Name FROM Staff s JOIN Role r ON s.Role_ID = r.Role_ID WHERE s.Email = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return extractStaffFromResultSet(rs);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int countStaffByFilter(String searchId, String searchName, String searchDept) {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM Staff s WHERE 1=1");
        if (searchId != null && !searchId.trim().isEmpty()) sql.append(" AND CAST(s.StaffID AS TEXT) LIKE ?");
        if (searchName != null && !searchName.trim().isEmpty()) sql.append(" AND s.FullName ILIKE ?"); 
        if (searchDept != null && !searchDept.trim().isEmpty()) sql.append(" AND s.Department ILIKE ?");

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            if (searchId != null && !searchId.trim().isEmpty()) ps.setString(paramIndex++, "%" + searchId.trim() + "%");
            if (searchName != null && !searchName.trim().isEmpty()) ps.setString(paramIndex++, "%" + searchName.trim() + "%");
            if (searchDept != null && !searchDept.trim().isEmpty()) ps.setString(paramIndex++, "%" + searchDept.trim() + "%");

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) { 
            e.printStackTrace(); 
        }
        return 0;
    }

    public List<Staff> getStaffByFilterPaging(String searchId, String searchName, String searchDept, int offset, int limit) {
        List<Staff> list = new java.util.ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT s.*, r.Role_Name FROM Staff s JOIN Role r ON s.Role_ID = r.Role_ID WHERE 1=1");

        if (searchId != null && !searchId.trim().isEmpty()) sql.append(" AND CAST(s.StaffID AS TEXT) LIKE ?");
        if (searchName != null && !searchName.trim().isEmpty()) sql.append(" AND s.FullName ILIKE ?");
        if (searchDept != null && !searchDept.trim().isEmpty()) sql.append(" AND s.Department ILIKE ?");

        sql.append(" ORDER BY s.StaffID DESC LIMIT ? OFFSET ?");

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            if (searchId != null && !searchId.trim().isEmpty()) ps.setString(paramIndex++, "%" + searchId.trim() + "%");
            if (searchName != null && !searchName.trim().isEmpty()) ps.setString(paramIndex++, "%" + searchName.trim() + "%");
            if (searchDept != null && !searchDept.trim().isEmpty()) ps.setString(paramIndex++, "%" + searchDept.trim() + "%");

            ps.setInt(paramIndex++, limit);
            ps.setInt(paramIndex, offset);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(extractStaffFromResultSet(rs));
                }
            }
        } catch (Exception e) { 
            e.printStackTrace(); 
        }
        return list;
    }

    // ====================================================================================
    // CÁC HÀM BỔ SUNG MỚI DÀNH CHO NGHIỆP VỤ AUTH (THÀNH VIÊN 2)
    // ====================================================================================

    /**
     * Cập nhật trạng thái hoạt động (Khoá/Mở khoá tài khoản)
     */
    public boolean updateAccountStatus(int staffId, boolean isActive) {
        String sql = "UPDATE Staff SET IsActive = ? WHERE StaffID = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBoolean(1, isActive);
            ps.setInt(2, staffId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            throw new RuntimeException("Lỗi khi cập nhật trạng thái tài khoản: " + e.getMessage(), e);
        }
    }

    /**
     * Cập nhật mật khẩu (Hỗ trợ đổi mật khẩu hoặc quên mật khẩu)
     */
    public boolean updatePassword(int staffId, String newHashedPassword) {
        String sql = "UPDATE Staff SET Password = ? WHERE StaffID = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newHashedPassword);
            ps.setInt(2, staffId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            throw new RuntimeException("Lỗi khi cập nhật mật khẩu: " + e.getMessage(), e);
        }
    }
}